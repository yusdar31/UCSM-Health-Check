# Dokumentasi Generate-UCSHealthCheck-v11.ps1

## 1. Tujuan

`Generate-UCSHealthCheck-v11.ps1` digunakan untuk mengambil inventory dan status kesehatan Cisco UCS Manager, lalu menghasilkan laporan HTML dan file CSV pendukung.

Script ini cocok digunakan untuk:

- pemeriksaan rutin Cisco UCS;
- dokumentasi sebelum dan setelah annual shutdown;
- verifikasi inventory perangkat;
- audit fault, firmware, service profile, port, power, dan license;
- pengumpulan bukti operasional.

---

## 2. Prasyarat

### Sistem operasi

Jalankan script pada komputer Windows yang dapat mengakses IP Cisco UCS Manager melalui jaringan.

### PowerShell

Disarankan menggunakan **Windows PowerShell 5.1**.

Periksa versi PowerShell:

```powershell
$PSVersionTable.PSVersion
```

### Cisco UCS PowerTool

Module berikut harus tersedia:

```powershell
Cisco.UCSManager
```

Periksa instalasi:

```powershell
Get-Module Cisco.UCSManager -ListAvailable
```

Periksa versinya:

```powershell
Get-Module Cisco.UCSManager -ListAvailable |
    Select-Object Name, Version, ModuleBase
```

Script ini telah digunakan dengan Cisco UCS PowerTool `3.0.6.21`.

### Akses UCS Manager

Akun yang digunakan harus memiliki izin baca terhadap inventory dan status UCS. Untuk penggunaan laporan saja, gunakan akun read-only apabila kebijakan perusahaan memungkinkan.

### Konektivitas

Pastikan komputer dapat mengakses UCS Manager:

```powershell
Test-Connection 10.222.16.198 -Count 2
```

Uji port HTTPS:

```powershell
Test-NetConnection 10.222.16.198 -Port 443
```

---

## 3. Lokasi File

Contoh struktur folder:

```text
D:\MSI\
└── Generate-UCSHealthCheck-v11.ps1
```

Folder hasil secara default:

```text
C:\UCS-Report\
```

Setiap eksekusi akan membuat subfolder berdasarkan waktu:

```text
C:\UCS-Report\20260724-173219\
```

---

## 4. Parameter Script

| Parameter | Wajib | Nilai bawaan | Fungsi |
|---|---:|---|---|
| `-UcsIp` | Ya | Tidak ada | IP virtual atau hostname UCS Manager |
| `-OutputDirectory` | Tidak | `C:\UCS-Report` | Folder utama penyimpanan laporan |
| `-PrimaryFabric` | Tidak | `A` | Menentukan Fabric Interconnect yang berperan sebagai primary; hanya menerima `A` atau `B` |
| `-IncludeRawCsv` | Tidak | Tidak aktif | Mengekspor data mentah tambahan ke CSV |
| `-OpenReport` | Tidak | Tidak aktif | Membuka laporan HTML setelah proses selesai |

Contoh IP UCS Manager:

```text
10.222.16.198
```

Gunakan **virtual IP UCS Manager**, bukan IP Fabric A atau Fabric B, kecuali memang terdapat kebutuhan khusus.

---

## 5. Cara Menjalankan

### Langkah 1 — Buka PowerShell

Disarankan membuka Windows PowerShell sebagai Administrator agar tidak terkendala kebijakan eksekusi atau hak menulis folder.

### Langkah 2 — Izinkan eksekusi untuk sesi saat ini

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Perubahan ini hanya berlaku pada jendela PowerShell yang sedang digunakan.

### Langkah 3 — Masuk ke folder script

```powershell
cd D:\MSI
```

### Langkah 4 — Jalankan script

```powershell
.\Generate-UCSHealthCheck-v11.ps1 `
  -UcsIp "10.222.16.198" `
  -PrimaryFabric A `
  -OutputDirectory "C:\UCS-Report" `
  -IncludeRawCsv `
  -OpenReport
```

Versi satu baris:

```powershell
.\Generate-UCSHealthCheck-v11.ps1 -UcsIp "10.222.16.198" -PrimaryFabric A -OutputDirectory "C:\UCS-Report" -IncludeRawCsv -OpenReport
```

Script akan meminta:

```text
Username UCS Manager:
Password UCS Manager:
```

Password dimasukkan sebagai secure string dan tidak ditampilkan di layar.

---

## 6. Contoh Penggunaan

### Laporan standar

```powershell
.\Generate-UCSHealthCheck-v11.ps1 -UcsIp "10.222.16.198"
```

### Menyimpan hasil ke drive lain

```powershell
.\Generate-UCSHealthCheck-v11.ps1 `
  -UcsIp "10.222.16.198" `
  -OutputDirectory "D:\UCS-Reports"
```

### Membuka laporan otomatis

```powershell
.\Generate-UCSHealthCheck-v11.ps1 `
  -UcsIp "10.222.16.198" `
  -OpenReport
```

### Menyertakan seluruh CSV troubleshooting

```powershell
.\Generate-UCSHealthCheck-v11.ps1 `
  -UcsIp "10.222.16.198" `
  -IncludeRawCsv
```

### Jika Fabric B sedang menjadi primary

```powershell
.\Generate-UCSHealthCheck-v11.ps1 `
  -UcsIp "10.222.16.198" `
  -PrimaryFabric B `
  -IncludeRawCsv `
  -OpenReport
```

---

## 7. Isi Laporan

Laporan HTML mencakup bagian berikut.

### Executive Summary

Berisi:

- nama UCS domain;
- virtual IP;
- versi UCS Manager;
- waktu pembuatan laporan;
- jumlah Fabric Interconnect;
- jumlah chassis;
- jumlah IO Module;
- jumlah blade server;
- jumlah active fault;
- jumlah fault Critical, Major, dan Minor;
- health score.

### Fabric Interconnect

Berisi:

- Fabric ID;
- cluster role;
- model;
- serial number;
- system firmware;
- kernel firmware;
- management IP;
- port yang digunakan;
- informasi license;
- operability;
- thermal status.

### Chassis

Berisi:

- chassis ID;
- model;
- serial;
- operability;
- power;
- PSU redundancy;
- thermal;
- jumlah PSU;
- slot terpakai;
- slot tersedia.

### IO Module

Berisi:

- chassis;
- fabric;
- model;
- serial;
- channel/slot;
- running firmware;
- backup firmware;
- operability.

### Power Supply Unit

Berisi inventory PSU Fabric Interconnect dan chassis, bergantung pada object yang dikembalikan UCS PowerTool.

### Server UCS

Berisi:

- chassis;
- slot;
- model;
- serial;
- service profile;
- jumlah CPU;
- jumlah core;
- memory;
- firmware CIMC;
- power state;
- thermal;
- status.

### Server Power Statistics

Berisi konsumsi daya, arus, dan tegangan server apabila statistik tersedia.

### Active Faults

Berisi:

- severity;
- fault code;
- affected object;
- description;
- waktu fault dibuat;
- waktu transisi terakhir.

### Service Profiles

Berisi service profile dan asosiasinya dengan blade.

### Firmware Inventory

Berisi object firmware yang ditemukan pada UCS Manager.

### License Summary

Berisi informasi feature license dan feature line yang dapat dibaca melalui UCS PowerTool.

---

## 8. File Output

File utama:

```text
UCS-Health-Check-YYYYMMDD-HHMMSS.html
```

File CSV standar dapat mencakup:

```text
FabricInterconnect.csv
Chassis.csv
IOModule.csv
PSUInventory.csv
Servers.csv
ServerPower.csv
Faults.csv
ServiceProfiles.csv
Firmware.csv
Licenses.csv
```

Jika `-IncludeRawCsv` digunakan, script juga menghasilkan data mentah seperti:

```text
RawFabricPorts.csv
RawServerPorts.csv
RawUplinkPorts.csv
RawFcPorts.csv
RawAppliancePorts.csv
RawLicenseFeatures.csv
RawLicenseLines.csv
```

CSV mentah berguna untuk:

- troubleshooting mapping property PowerTool;
- memeriksa port yang salah klasifikasi;
- memeriksa license yang tidak tampil pada laporan;
- pengembangan script versi berikutnya.

---

## 9. Validasi Setelah Script Berjalan

Periksa Executive Summary dan cocokkan dengan UCS Manager.

Untuk lingkungan saat dokumentasi ini dibuat, jumlah normalnya adalah:

```text
Fabric Interconnects : 2
Chassis              : 5
IO Modules           : 10
Blade Servers        : 18
```

Jumlah dapat berubah apabila terdapat penambahan atau pelepasan perangkat.

Validasi penting:

1. Fabric Interconnect tidak muncul dua kali.
2. Chassis dan blade tidak duplikat.
3. Serial number sesuai dengan UCS Manager.
4. Service profile sesuai dengan server terkait.
5. Active fault sesuai menu Faults pada UCS Manager.
6. Primary Fabric sesuai kondisi cluster saat laporan dibuat.
7. Folder output berisi HTML dan CSV tanpa ukuran nol byte.

---

## 10. Pengelolaan Sesi UCS PowerTool

Script versi 11 membersihkan sesi UCS lama sebelum melakukan koneksi baru. Hal ini mencegah inventory muncul dua kali.

Untuk memeriksa sesi secara manual:

```powershell
Get-UcsPSSession
```

Untuk memutus seluruh sesi:

```powershell
Get-UcsPSSession | ForEach-Object {
    Disconnect-Ucs -Ucs $_ -ErrorAction SilentlyContinue
}
```

Jangan menjalankan dua instance script secara bersamaan dari console yang sama.

---

## 11. Troubleshooting

### Cisco.UCSManager belum terpasang

Pesan:

```text
Cisco.UCSManager belum terpasang.
```

Periksa module:

```powershell
Get-Module Cisco.UCSManager -ListAvailable
```

Instal atau perbaiki Cisco UCS PowerTool sebelum menjalankan script kembali.

### Script tidak dapat dijalankan

Pesan umum:

```text
running scripts is disabled on this system
```

Solusi untuk sesi aktif:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

### MultipleDefaultUcs not allowed

Periksa sesi:

```powershell
Get-UcsPSSession
```

Putuskan sesi lama:

```powershell
Get-UcsPSSession | ForEach-Object {
    Disconnect-Ucs -Ucs $_ -ErrorAction SilentlyContinue
}
```

Versi 11 sudah melakukan pembersihan ini secara otomatis.

### Login gagal

Periksa:

- username dan password;
- apakah akun terkunci;
- koneksi jaringan ke UCS Manager;
- penggunaan virtual IP yang benar;
- hak akses akun.

Uji port:

```powershell
Test-NetConnection 10.222.16.198 -Port 443
```

### Sertifikat tidak dipercaya

Script mengatur:

```powershell
-InvalidCertificateAction Ignore
```

Karena itu sertifikat self-signed UCS Manager tidak seharusnya menghentikan proses. Tetap pastikan IP tujuan benar untuk menghindari koneksi ke perangkat yang salah.

### Data muncul dua kali

Penyebab umum adalah lebih dari satu sesi PowerTool aktif. Versi 11 membersihkan sesi lama, tetapi tetap periksa:

```powershell
Get-UcsPSSession
```

Setelah koneksi berhasil, seharusnya hanya ada satu sesi aktif.

### Kolom kosong atau `N/A`

Beberapa property berbeda antar versi UCSM, model perangkat, dan versi Cisco UCS PowerTool. Kolom kosong tidak selalu menunjukkan kerusakan perangkat.

Gunakan file `Raw*.csv` untuk melihat property asli yang dikembalikan API.

### Port Used tidak sesuai

Bandingkan:

```text
RawFabricPorts.csv
RawServerPorts.csv
RawUplinkPorts.csv
RawFcPorts.csv
RawAppliancePorts.csv
```

Periksa kolom seperti:

```text
Dn
SwitchId
IfRole
Role
Transport
AdminState
OperState
```

### License kosong atau tidak lengkap

Periksa:

```text
RawLicenseFeatures.csv
RawLicenseLines.csv
```

UCS Manager dan model Fabric Interconnect tertentu dapat mengekspos informasi license dengan property yang berbeda.

### Laporan tidak terbuka otomatis

Parameter `-OpenReport` hanya mencoba membuka HTML menggunakan aplikasi default Windows. File tetap tersimpan pada folder output meskipun browser gagal dibuka.

---

## 12. Prosedur Annual Shutdown

### Sebelum shutdown

1. Jalankan script dengan `-IncludeRawCsv`.
2. Simpan folder hasil dengan label `PRE-SHUTDOWN`.
3. Pastikan tidak ada fault Critical atau Major yang belum ditangani.
4. Periksa HA Fabric Interconnect.
5. Periksa PSU, IOM, thermal, dan operability.
6. Simpan Full State Backup UCS Manager.
7. Simpan System Configuration Backup.
8. Simpan Tech Support Bundle apabila diperlukan.
9. Salin laporan ke lokasi penyimpanan bersama atau backup.

Contoh:

```powershell
.\Generate-UCSHealthCheck-v11.ps1 `
  -UcsIp "10.222.16.198" `
  -PrimaryFabric A `
  -OutputDirectory "D:\Annual-Shutdown\PRE-SHUTDOWN" `
  -IncludeRawCsv `
  -OpenReport
```

### Setelah startup

1. Tunggu Fabric Interconnect, IOM, chassis, dan blade stabil.
2. Jalankan script kembali.
3. Simpan hasil dengan label `POST-STARTUP`.
4. Bandingkan jumlah perangkat, firmware, service profile, dan fault.
5. Pastikan tidak ada perangkat yang missing atau inoperable.
6. Dokumentasikan perubahan fault sebelum dan sesudah shutdown.

Contoh:

```powershell
.\Generate-UCSHealthCheck-v11.ps1 `
  -UcsIp "10.222.16.198" `
  -PrimaryFabric A `
  -OutputDirectory "D:\Annual-Shutdown\POST-STARTUP" `
  -IncludeRawCsv `
  -OpenReport
```

---

## 13. Keamanan

- Jangan menyimpan password UCS Manager di dalam script.
- Jangan mengirim laporan ke pihak luar tanpa pemeriksaan karena serial number, IP, hostname, service profile, dan fault dapat bersifat sensitif.
- Batasi akses folder hasil laporan.
- Gunakan akun read-only untuk aktivitas reporting apabila memungkinkan.
- Hapus file output dari komputer sementara setelah dipindahkan ke repositori resmi.
- Jangan mengubah pengaturan sertifikat global secara permanen tanpa persetujuan tim keamanan.

---

## 14. Pemeliharaan Script

Sebelum mengganti versi script:

1. Simpan versi yang sudah terbukti berjalan.
2. Gunakan penomoran versi baru, misalnya `v12`.
3. Uji pada UCS nonproduksi atau dalam mode read-only.
4. Bandingkan jumlah inventory dengan laporan versi sebelumnya.
5. Jangan menimpa laporan lama.
6. Simpan catatan perubahan.

Contoh changelog:

```text
v11
- Membersihkan sesi UCS lama.
- Mencegah inventory terduplikasi.
- Menonaktifkan multiple default UCS session.
```

---

## 15. Pemeriksaan Syntax Tanpa Menjalankan Script

Gunakan perintah berikut:

```powershell
$errors = $null
[System.Management.Automation.Language.Parser]::ParseFile(
    "D:\MSI\Generate-UCSHealthCheck-v11.ps1",
    [ref]$null,
    [ref]$errors
) | Out-Null

$errors
```

Jika tidak ada output pada `$errors`, syntax PowerShell valid.

---

## 16. Perintah Cepat Operasional

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
cd D:\MSI
.\Generate-UCSHealthCheck-v11.ps1 -UcsIp "10.222.16.198" -PrimaryFabric A -OutputDirectory "C:\UCS-Report" -IncludeRawCsv -OpenReport
```

---

## 17. Informasi Versi

```text
Script      : Generate-UCSHealthCheck-v11.ps1
Target      : Cisco UCS Manager
PowerTool   : Cisco.UCSManager
Output      : HTML dan CSV
Mode akses  : Read-only inventory dan health collection
```
