﻿param(
    [Parameter(Mandatory = $true)]
    [string]$UcsIp,

    [string]$OutputDirectory = "C:\UCS-Report",

    [ValidateSet("A", "B")]
    [string]$PrimaryFabric = "A",

    [switch]$OpenReport,

    [switch]$IncludeRawCsv
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "Continue"

function Get-FirstPropertyValue {
    param(
        [AllowNull()]$InputObject,
        [string[]]$Names,
        $Default = ""
    )

    if ($null -eq $InputObject) { return $Default }

    foreach ($name in $Names) {
        $property = $InputObject.PSObject.Properties[$name]
        if ($null -ne $property) {
            $value = $property.Value
            if ($null -ne $value -and "$value" -ne "") { return $value }
        }
    }
    return $Default
}

function Invoke-UcsCommandSafe {
    param(
        [Parameter(Mandatory = $true)][string]$CommandName,
        [scriptblock]$ScriptBlock
    )

    if (-not (Get-Command $CommandName -ErrorAction SilentlyContinue)) {
        Write-Warning "Cmdlet $CommandName tidak tersedia."
        return @()
    }

    try {
        return @(& $ScriptBlock)
    }
    catch {
        Write-Warning "$CommandName gagal: $($_.Exception.Message)"
        return @()
    }
}

function Get-UcsClassSafe {
    param([Parameter(Mandatory = $true)][string[]]$ClassIds)

    foreach ($classId in $ClassIds) {
        try {
            $result = @(Get-UcsManagedObject -ClassId $classId -ErrorAction Stop)
            if ($result.Count -gt 0) { return $result }
        }
        catch {
            # Try the next known class name.
        }
    }
    return @()
}

function ConvertTo-HtmlTable {
    param(
        [Parameter(Mandatory = $true)][string]$Title,
        [AllowNull()][object[]]$Data = @(),
        [string]$CssClass = ""
    )

    $safeData = @($Data)
    if ($safeData.Count -eq 0) {
        return "<section><h2>$Title</h2><p class='empty'>No data returned.</p></section>"
    }

    $fragment = $safeData | ConvertTo-Html -Fragment
    if ($CssClass) {
        $fragment = $fragment -replace '<table>', "<table class='$CssClass'>"
    }
    return "<section><h2>$Title</h2>$fragment</section>"
}

function Get-FabricFromDn {
    param([string]$Dn)
    if ($Dn -match '(?i)switch-([AB])') { return $Matches[1].ToUpper() }
    if ($Dn -match '(?i)fabric/lan/([AB])') { return $Matches[1].ToUpper() }
    if ($Dn -match '(?i)fabric/san/([AB])') { return $Matches[1].ToUpper() }
    return ""
}

function Get-IdFromDn {
    param([string]$Dn, [string]$Pattern)
    if ($Dn -match $Pattern) { return $Matches[1] }
    return ""
}

function Test-PortInUse {
    param($Port)
    $admin = ([string](Get-FirstPropertyValue $Port @("AdminState", "AdminSt", "State") "")).ToLower()
    $oper  = ([string](Get-FirstPropertyValue $Port @("OperState", "Operability", "LinkState") "")).ToLower()
    $role  = ([string](Get-FirstPropertyValue $Port @("IfRole", "Role", "PortRole") "")).ToLower()
    $type  = ([string](Get-FirstPropertyValue $Port @("IfType", "Type") "")).ToLower()

    if ($admin -in @("disabled", "disable", "down", "unconfigured")) { return $false }
    if ($role -in @("unknown", "unconfigured", "none")) { return $false }
    if ($type -in @("unknown", "unconfigured")) { return $false }
    if ($oper -in @("failed", "error", "sfp-not-present", "link-down") -and $role -eq "") { return $false }
    return $true
}

function Get-PortCountByFabricFiltered {
    param([object[]]$Objects)
    $counts = @{ A = 0; B = 0 }
    $seen = @{}
    foreach ($item in @($Objects)) {
        if (-not (Test-PortInUse $item)) { continue }
        $dn = [string](Get-FirstPropertyValue $item @("Dn") "")
        $fabric = ([string](Get-FirstPropertyValue $item @("SwitchId", "FabricId") "")).ToUpper()
        if ($fabric -notin @("A", "B")) { $fabric = Get-FabricFromDn $dn }
        if ($fabric -notin @("A", "B")) { continue }
        $slot = Get-FirstPropertyValue $item @("SlotId", "Slot") ""
        $port = Get-FirstPropertyValue $item @("PortId", "Port") ""
        $aggr = Get-FirstPropertyValue $item @("AggrPortId", "AggrPort") ""
        $key = if ($dn) { $dn } else { "$fabric|$slot|$port|$aggr" }
        if (-not $seen.ContainsKey($key)) {
            $seen[$key] = $true
            $counts[$fabric]++
        }
    }
    return $counts
}

function Get-FirmwareVersionForDn {
    param([object[]]$Firmware, [string]$DnRegex, [string]$TypeRegex, [string]$DeploymentRegex = "")
    $match = @($Firmware | Where-Object {
        $dn = [string](Get-FirstPropertyValue $_ @("Dn") "")
        $type = [string](Get-FirstPropertyValue $_ @("Type") "")
        $deployment = [string](Get-FirstPropertyValue $_ @("Deployment") "")
        $dn -match $DnRegex -and $type -match $TypeRegex -and ($DeploymentRegex -eq "" -or $deployment -match $DeploymentRegex)
    } | Select-Object -First 1)
    if ($match.Count -gt 0) { return Get-FirstPropertyValue $match[0] @("Version", "PackageVersion") "" }
    return ""
}

function Get-PortCountByFabric {
    param([object[]]$Objects)

    $counts = @{ A = 0; B = 0 }
    foreach ($item in @($Objects)) {
        $fabric = Get-FirstPropertyValue $item @("SwitchId", "FabricId", "Id") ""
        if ($fabric -notin @("A", "B")) {
            $fabric = Get-FabricFromDn (Get-FirstPropertyValue $item @("Dn") "")
        }
        if ($fabric -in @("A", "B")) { $counts[$fabric]++ }
    }
    return $counts
}

if (-not (Get-Module Cisco.UCSManager -ListAvailable)) {
    throw "Cisco.UCSManager belum terpasang."
}

Import-Module Cisco.UCSManager -Force
# Bersihkan sesi UCS lama agar setiap object tidak terbaca dua kali.
Get-UcsPSSession -ErrorAction SilentlyContinue | ForEach-Object {
    Disconnect-Ucs -Ucs $_ -ErrorAction SilentlyContinue | Out-Null
}

Set-UcsPowerToolConfiguration -SupportMultipleDefaultUcs $false -InvalidCertificateAction Ignore -Force | Out-Null

New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$reportFolder = Join-Path $OutputDirectory $timestamp
New-Item -ItemType Directory -Path $reportFolder -Force | Out-Null
$htmlPath = Join-Path $reportFolder "UCS-Health-Check-$timestamp.html"

$username = Read-Host "Username UCS Manager"
$securePassword = Read-Host "Password UCS Manager" -AsSecureString
$credential = New-Object System.Management.Automation.PSCredential($username, $securePassword)

Write-Progress -Activity "UCS Health Check" -Status "Connecting to UCS Manager" -PercentComplete 3
$connection = Connect-Ucs -Name $UcsIp -Credential $credential

try {
    $session = Get-UcsPSSession | Select-Object -First 1
    $domainName = Get-FirstPropertyValue $session @("Ucs") (Get-FirstPropertyValue $connection @("Ucs") "Unknown")
    $ucsmVersion = Get-FirstPropertyValue $session @("Version") (Get-FirstPropertyValue $connection @("Version") "")

    $roleMap = @{
        A = if ($PrimaryFabric -eq "A") { "primary" } else { "subordinate" }
        B = if ($PrimaryFabric -eq "B") { "primary" } else { "subordinate" }
    }

    Write-Progress -Activity "UCS Health Check" -Status "Collecting firmware and port information" -PercentComplete 10
    $firmwareRunning = Get-UcsClassSafe @("firmwareRunning")
    # Get-UcsFabricPort is the most reliable inventory source on PowerTool 3.0.6.x.
    $fabricPorts = Invoke-UcsCommandSafe "Get-UcsFabricPort" { Get-UcsFabricPort }
    $serverPorts = @()
    $uplinkPorts = @()
    $fcUplinkPorts = @()
    $appliancePorts = @()

    if ($fabricPorts.Count -gt 0) {
        foreach ($port in $fabricPorts) {
            $role = ([string](Get-FirstPropertyValue $port @("IfRole", "Role", "PortRole") "")).ToLower()
            $transport = ([string](Get-FirstPropertyValue $port @("Transport", "IfType", "Type") "")).ToLower()
            if ($role -match "server") { $serverPorts += $port }
            elseif ($role -match "appliance|storage") { $appliancePorts += $port }
            elseif ($role -match "uplink" -and $transport -match "fc|fibre") { $fcUplinkPorts += $port }
            elseif ($role -match "uplink") { $uplinkPorts += $port }
            elseif ($transport -match "fc|fibre") { $fcUplinkPorts += $port }
        }
    }

    if ($serverPorts.Count -eq 0) {
        foreach ($cmd in @("Get-UcsServerPort", "Get-UcsEtherServerIntFIo")) {
            if (Get-Command $cmd -ErrorAction SilentlyContinue) { try { $serverPorts += @(& $cmd) } catch {} }
        }
    }
    if ($uplinkPorts.Count -eq 0) {
        foreach ($cmd in @("Get-UcsUplinkPort", "Get-UcsSwPhysEtherEp")) {
            if (Get-Command $cmd -ErrorAction SilentlyContinue) { try { $uplinkPorts += @(& $cmd) } catch {} }
        }
    }
    if ($fcUplinkPorts.Count -eq 0) {
        foreach ($cmd in @("Get-UcsFcUplinkPort", "Get-UcsFiFcPort", "Get-UcsSwPhysFcEp")) {
            if (Get-Command $cmd -ErrorAction SilentlyContinue) { try { $fcUplinkPorts += @(& $cmd) } catch {} }
        }
    }
    if ($appliancePorts.Count -eq 0) {
        $appliancePorts = Invoke-UcsCommandSafe "Get-UcsAppliancePort" { Get-UcsAppliancePort }
    }

    $serverPortCounts = Get-PortCountByFabricFiltered $serverPorts
    $uplinkPortCounts = Get-PortCountByFabricFiltered $uplinkPorts
    $fcPortCounts = Get-PortCountByFabricFiltered $fcUplinkPorts
    $appliancePortCounts = Get-PortCountByFabricFiltered $appliancePorts

    $licenseFeatures = Invoke-UcsCommandSafe "Get-UcsLicenseFeature" { Get-UcsLicenseFeature }
    $licenseLines = Invoke-UcsCommandSafe "Get-UcsLicenseFeatureLine" { Get-UcsLicenseFeatureLine }

    Write-Progress -Activity "UCS Health Check" -Status "Collecting Fabric Interconnect inventory" -PercentComplete 18
    $fabricInterconnects = @(Get-UcsNetworkElement | Sort-Object Id | ForEach-Object {
        $fi = $_
        $fabric = "$($fi.Id)"
        $kernelVersion = Get-FirmwareVersionForDn $firmwareRunning "(?i)^sys/switch-$fabric/mgmt/fw-kernel$" "(?i)switch-kernel" "(?i)kernel"
        $switchSystemVersion = Get-FirmwareVersionForDn $firmwareRunning "(?i)^sys/switch-$fabric/mgmt/fw-system$" "(?i)switch-software" "(?i)system"

        $relatedLicenses = @($licenseLines + $licenseFeatures | Where-Object {
            $dn = [string](Get-FirstPropertyValue $_ @("Dn") "")
            $scope = [string](Get-FirstPropertyValue $_ @("Scope", "FeatureName", "Name") "")
            $dn -match "(?i)switch-$fabric" -or $scope -match "(?i)(port|ether|fc|activation)"
        })

        $licensedItems = @()
        foreach ($lic in $relatedLicenses) {
            $name = Get-FirstPropertyValue $lic @("Name", "FeatureName", "Feature") "Port"
            $total = Get-FirstPropertyValue $lic @("TotalQuantity", "Quantity", "AbsQuant", "Count", "DefQuant", "Available") ""
            $used = Get-FirstPropertyValue $lic @("UsedQuantity", "UsedQuant", "Used", "UsedCount") ""
            if ($total -ne "" -or $used -ne "") {
                if ($used -ne "") { $licensedItems += "$name=$used/$total" }
                else { $licensedItems += "$name=$total" }
            }
        }
        $licensed = ($licensedItems | Select-Object -Unique) -join "; "
        if (-not $licensed) { $licensed = "See License Summary" }

        $portSummary = "Appliance=$($appliancePortCounts[$fabric]), FC=$($fcPortCounts[$fabric]), Server=$($serverPortCounts[$fabric]), Uplink=$($uplinkPortCounts[$fabric])"

        [PSCustomObject]@{
            "Fabric ID"      = $fabric
            "Cluster Role"   = $roleMap[$fabric]
            "Model"          = Get-FirstPropertyValue $fi @("Model") ""
            "Serial"         = Get-FirstPropertyValue $fi @("Serial") ""
            "System"         = $switchSystemVersion
            "Kernel"         = $kernelVersion
            "IP"             = Get-FirstPropertyValue $fi @("OobIfIp") ""
            "Ports Used"     = $portSummary
            "Ports Licensed" = $licensed
            "Operability"    = Get-FirstPropertyValue $fi @("Operability") ""
            "Thermal"        = Get-FirstPropertyValue $fi @("Thermal") ""
        }
    })

    Write-Progress -Activity "UCS Health Check" -Status "Collecting chassis inventory" -PercentComplete 28
    $chassisRaw = Invoke-UcsCommandSafe "Get-UcsChassis" { Get-UcsChassis }
    $psuRaw = @()
    foreach ($cmd in @("Get-UcsPsu", "Get-UcsEquipmentPsu")) {
        if (Get-Command $cmd -ErrorAction SilentlyContinue) { try { $psuRaw += @(& $cmd) } catch {} }
    }
    if ($psuRaw.Count -eq 0) { $psuRaw = Get-UcsClassSafe @("equipmentPsu") }
    $bladeForSlots = Invoke-UcsCommandSafe "Get-UcsBlade" { Get-UcsBlade }
    $chassis = @($chassisRaw | Sort-Object { [int](Get-FirstPropertyValue $_ @("Id") 0) } | ForEach-Object {
        $chId = [string](Get-FirstPropertyValue $_ @("Id") "")
        $slots = Get-FirstPropertyValue $_ @("NumOfSlots", "Slots") ""
        if ($slots -eq "") {
            $model = [string](Get-FirstPropertyValue $_ @("Model") "")
            if ($model -match "5108") { $slots = 8 }
        }
        $usedSlotIds = @($bladeForSlots | Where-Object { [string](Get-FirstPropertyValue $_ @("ChassisId") "") -eq $chId } | ForEach-Object { Get-FirstPropertyValue $_ @("SlotId") "" } | Where-Object { $_ -ne "" } | Select-Object -Unique)
        $used = $usedSlotIds.Count
        $available = if ($slots -ne "") { [int]$slots - [int]$used } else { "" }
        $chassisPsus = @($psuRaw | Where-Object { [string](Get-FirstPropertyValue $_ @("Dn") "") -match "(?i)^sys/chassis-$chId/psu-" })
        $psuCount = $chassisPsus.Count
        $psuOperable = @($chassisPsus | Where-Object {
            [string](Get-FirstPropertyValue $_ @("Operability", "OperState", "Presence") "") -match "(?i)operable|ok|equipped|present"
        }).Count
        $psuSummary = if ($psuCount -gt 0) { "$psuOperable/$psuCount operable" } else { "" }
        [PSCustomObject]@{
            "ID"               = Get-FirstPropertyValue $_ @("Id") ""
            "Model"            = Get-FirstPropertyValue $_ @("Model") ""
            "Serial"           = Get-FirstPropertyValue $_ @("Serial") ""
            "Status"           = Get-FirstPropertyValue $_ @("OperState", "Operability") ""
            "Operability"      = Get-FirstPropertyValue $_ @("Operability", "OperState") ""
            "Power"            = Get-FirstPropertyValue $_ @("Power", "PowerState") ""
            "Power Redundancy" = if ((Get-FirstPropertyValue $_ @("PowerRedundancy", "PsuState") "") -ne "") { Get-FirstPropertyValue $_ @("PowerRedundancy", "PsuState") "" } else { $psuSummary }
            "Thermal"          = Get-FirstPropertyValue $_ @("Thermal") ""
            "PSUs"             = if ($psuCount -gt 0) { $psuCount } else { Get-FirstPropertyValue $_ @("NumOfPsu", "PsuCount") "" }
            "Slots Used"       = $used
            "Slots Available"  = $available
        }
    })

    Write-Progress -Activity "UCS Health Check" -Status "Collecting IO Modules" -PercentComplete 38
    $iomRaw = @()
    foreach ($cmd in @("Get-UcsIocard", "Get-UcsEquipmentIoCard", "Get-UcsEquipmentIOCard")) {
        if (Get-Command $cmd -ErrorAction SilentlyContinue) {
            $iomRaw = @(& $cmd)
            if ($iomRaw.Count -gt 0) { break }
        }
    }
    if ($iomRaw.Count -eq 0) {
        $iomRaw = Get-UcsClassSafe @("equipmentIOCard", "equipmentIoCard")
    }

    $iom = @($iomRaw | Sort-Object {
        Get-FirstPropertyValue $_ @("ChassisId") 0
    }, {
        Get-FirstPropertyValue $_ @("Id", "Side") ""
    } | ForEach-Object {
        $dn = Get-FirstPropertyValue $_ @("Dn") ""
        $chassisId = Get-FirstPropertyValue $_ @("ChassisId") ""
        if ($chassisId -eq "" -and $dn -match 'chassis-(\d+)') { $chassisId = $Matches[1] }
        $slotId = Get-FirstPropertyValue $_ @("Id", "SlotId") ""
        if ($slotId -eq "" -and $dn -match '/slot-(\d+)') { $slotId = $Matches[1] }
        $fabricId = Get-FirstPropertyValue $_ @("Side", "SwitchId") ""
        if ($fabricId -notin @("A", "B")) {
            if ("$slotId" -eq "1") { $fabricId = "A" }
            elseif ("$slotId" -eq "2") { $fabricId = "B" }
            else { $fabricId = Get-FabricFromDn $dn }
        }
        $iomSystemDn = "^sys/chassis-$chassisId/slot-$slotId/mgmt/fw-system$"
        $iomBootDn = "^sys/chassis-$chassisId/slot-$slotId/mgmt/fw-boot-loader$"
        $iomRunning = Get-FirmwareVersionForDn $firmwareRunning $iomSystemDn "(?i)iocard" "(?i)system"
        $iomBackup = Get-FirmwareVersionForDn $firmwareRunning $iomBootDn "(?i)iocard" "(?i)boot-loader"
        $channel = Get-FirstPropertyValue $_ @("PeerDn", "ConnPath", "Channel") ""
        if ($channel -eq "" -and $dn -match '/slot-(\d+)') { $channel = "slot-$($Matches[1])" }
        [PSCustomObject]@{
            "Chassis"          = $chassisId
            "Fabric ID"        = $fabricId
            "Model"            = Get-FirstPropertyValue $_ @("Model") ""
            "Serial"           = Get-FirstPropertyValue $_ @("Serial") ""
            "Channel"          = $channel
            "Running Firmware" = if ($iomRunning) { $iomRunning } else { Get-FirstPropertyValue $_ @("OperFwVersion", "FirmwareVersion") "" }
            "Backup Firmware"  = if ($iomBackup) { $iomBackup } else { Get-FirstPropertyValue $_ @("BackupFwVersion") "" }
            "Operability"      = Get-FirstPropertyValue $_ @("Operability", "OperState") ""
        }
    })

    Write-Progress -Activity "UCS Health Check" -Status "Collecting blade servers" -PercentComplete 50
    $serversRaw = Invoke-UcsCommandSafe "Get-UcsBlade" { Get-UcsBlade }
    $servers = @($serversRaw | Sort-Object {
        [int](Get-FirstPropertyValue $_ @("ChassisId") 0)
    }, {
        [int](Get-FirstPropertyValue $_ @("SlotId") 0)
    } | ForEach-Object {
        $totalMemory = Get-FirstPropertyValue $_ @("TotalMemory") ""
        $memoryGb = if ($totalMemory -ne "") { [math]::Round(([double]$totalMemory / 1024), 0) } else { "" }
        $serverChassisId = Get-FirstPropertyValue $_ @("ChassisId") ""
        $serverSlotId = Get-FirstPropertyValue $_ @("SlotId") ""
        $cimcVersion = Get-FirmwareVersionForDn $firmwareRunning "(?i)^sys/chassis-$serverChassisId/blade-$serverSlotId/mgmt/fw-system$" "(?i)blade-controller" "(?i)system"
        [PSCustomObject]@{
            "Chassis"         = $serverChassisId
            "Slot"            = $serverSlotId
            "Model"           = Get-FirstPropertyValue $_ @("Model") ""
            "Serial"          = Get-FirstPropertyValue $_ @("Serial") ""
            "Service Profile" = Get-FirstPropertyValue $_ @("AssignedToDn", "AssignedTo") ""
            "CPU"             = Get-FirstPropertyValue $_ @("NumOfCpus") ""
            "Cores"           = Get-FirstPropertyValue $_ @("NumOfCores") ""
            "Memory (GB)"     = $memoryGb
            "CIMC"            = $cimcVersion
            "Power"           = Get-FirstPropertyValue $_ @("OperPower", "AdminPower") ""
            "Thermal"         = Get-FirstPropertyValue $_ @("Thermal") ""
            "Status"          = Get-FirstPropertyValue $_ @("OperState", "Operability") ""
        }
    })

    Write-Progress -Activity "UCS Health Check" -Status "Collecting server power statistics" -PercentComplete 60
    $powerRaw = @()
    foreach ($cmd in @("Get-UcsComputeMbPowerStats", "Get-UcsComputeBoardControllerPowerStats", "Get-UcsEquipmentPsuInputStats")) {
        if (Get-Command $cmd -ErrorAction SilentlyContinue) {
            try { $powerRaw += @(& $cmd) } catch { }
        }
    }
    if ($powerRaw.Count -eq 0) {
        $powerRaw = Get-UcsClassSafe @("computeMbPowerStats", "computeBoardControllerPowerStats")
    }

    $serverPower = @($powerRaw | ForEach-Object {
        $powerDn = Get-FirstPropertyValue $_ @("Dn") ""
        $powerChassis = ""
        $powerSlot = ""
        if ($powerDn -match "chassis-(\d+)/blade-(\d+)") { $powerChassis = $Matches[1]; $powerSlot = $Matches[2] }
        [PSCustomObject]@{
            "Chassis"          = $powerChassis
            "Slot"             = $powerSlot
            "Dn"                = $powerDn
            "Consumed Pwr"      = Get-FirstPropertyValue $_ @("ConsumedPower", "ConsumedPwr") ""
            "Consumed Pwr Avg"  = Get-FirstPropertyValue $_ @("ConsumedPowerAvg", "ConsumedPwrAvg") ""
            "Consumed Pwr Max"  = Get-FirstPropertyValue $_ @("ConsumedPowerMax", "ConsumedPwrMax") ""
            "Input Current"     = Get-FirstPropertyValue $_ @("InputCurrent") ""
            "Input Current Avg" = Get-FirstPropertyValue $_ @("InputCurrentAvg") ""
            "Input Voltage"     = Get-FirstPropertyValue $_ @("InputVoltage") ""
            "Input Voltage Avg" = Get-FirstPropertyValue $_ @("InputVoltageAvg") ""
            "Suspect"           = Get-FirstPropertyValue $_ @("Suspect") ""
        }
    })

    Write-Progress -Activity "UCS Health Check" -Status "Collecting faults and service profiles" -PercentComplete 72
    $faultsRaw = Invoke-UcsCommandSafe "Get-UcsFault" { Get-UcsFault }
    $faults = @($faultsRaw |
        Where-Object { (Get-FirstPropertyValue $_ @("Severity") "") -notin @("cleared", "info") } |
        Sort-Object Severity, LastTransition |
        ForEach-Object {
            [PSCustomObject]@{
                "Severity"        = Get-FirstPropertyValue $_ @("Severity") ""
                "Code"            = Get-FirstPropertyValue $_ @("Code") ""
                "Affected Object" = Get-FirstPropertyValue $_ @("Dn") ""
                "Description"     = Get-FirstPropertyValue $_ @("Descr", "Description") ""
                "Created"         = Get-FirstPropertyValue $_ @("Created") ""
                "Last Transition" = Get-FirstPropertyValue $_ @("LastTransition") ""
            }
        })

    $serviceProfilesRaw = Invoke-UcsCommandSafe "Get-UcsServiceProfile" { Get-UcsServiceProfile }
    $serviceProfiles = @($serviceProfilesRaw | Sort-Object Name | ForEach-Object {
        [PSCustomObject]@{
            "Name"          = Get-FirstPropertyValue $_ @("Name") ""
            "Organization"  = Get-FirstPropertyValue $_ @("Dn") ""
            "Assigned To"   = Get-FirstPropertyValue $_ @("PnDn", "AssignedToDn") ""
            "Association"   = Get-FirstPropertyValue $_ @("AssocState") ""
            "Operability"   = Get-FirstPropertyValue $_ @("OperState", "Operability") ""
            "Template Type" = Get-FirstPropertyValue $_ @("Type") ""
        }
    })

    Write-Progress -Activity "UCS Health Check" -Status "Collecting firmware summary" -PercentComplete 82
    $firmwareSummary = @($firmwareRunning | Where-Object {
        $type = [string](Get-FirstPropertyValue $_ @("Type") "")
        $deployment = [string](Get-FirstPropertyValue $_ @("Deployment") "")
        $type -in @("system", "switch-kernel", "switch-software", "iocard", "blade-controller", "blade-bios", "adaptor", "storage-controller", "psu") -and $deployment -eq "system"
    } | ForEach-Object {
        [PSCustomObject]@{
            "DN"         = Get-FirstPropertyValue $_ @("Dn") ""
            "Type"       = Get-FirstPropertyValue $_ @("Type") ""
            "Version"    = Get-FirstPropertyValue $_ @("Version", "PackageVersion") ""
            "Deployment" = Get-FirstPropertyValue $_ @("Deployment") ""
        }
    } | Sort-Object DN, Type)

    $licenseSummary = @($licenseFeatures | ForEach-Object {
        [PSCustomObject]@{
            "Feature"      = Get-FirstPropertyValue $_ @("Name", "FeatureName", "Feature") ""
            "Scope"        = Get-FirstPropertyValue $_ @("Scope", "Dn") ""
            "Total"        = Get-FirstPropertyValue $_ @("TotalQuantity", "Quantity", "AbsQuant", "DefQuant", "Available") ""
            "Used"         = Get-FirstPropertyValue $_ @("UsedQuantity", "UsedQuant", "Used", "UsedCount") ""
            "Grace Period" = Get-FirstPropertyValue $_ @("GracePeriod", "GracePeriodUsed") ""
            "Oper State"   = Get-FirstPropertyValue $_ @("OperState", "Status") ""
        }
    })

    $psuInventory = @($psuRaw | ForEach-Object {
        $dn = Get-FirstPropertyValue $_ @("Dn") ""
        $ch = ""; $id = ""
        if ($dn -match "chassis-(\d+)/psu-(\d+)") { $ch = $Matches[1]; $id = $Matches[2] }
        [PSCustomObject]@{
            "Chassis"    = $ch
            "PSU"        = $id
            "Model"      = Get-FirstPropertyValue $_ @("Model") ""
            "Serial"     = Get-FirstPropertyValue $_ @("Serial") ""
            "Presence"   = Get-FirstPropertyValue $_ @("Presence") ""
            "Operability"= Get-FirstPropertyValue $_ @("Operability", "OperState") ""
            "Power"      = Get-FirstPropertyValue $_ @("Power") ""
        }
    } | Sort-Object Chassis, PSU)

    $criticalCount = @($faults | Where-Object { $_.Severity -eq "critical" }).Count
    $majorCount = @($faults | Where-Object { $_.Severity -eq "major" }).Count
    $minorCount = @($faults | Where-Object { $_.Severity -eq "minor" }).Count
    $healthScore = 100 - ($criticalCount * 25) - ($majorCount * 10) - ($minorCount * 2)
    if ($healthScore -lt 0) { $healthScore = 0 }

    $summary = @(
        [PSCustomObject]@{ "Item" = "UCS Domain"; "Value" = $domainName }
        [PSCustomObject]@{ "Item" = "Virtual IP"; "Value" = $UcsIp }
        [PSCustomObject]@{ "Item" = "UCSM Version"; "Value" = $ucsmVersion }
        [PSCustomObject]@{ "Item" = "Generated"; "Value" = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss") }
        [PSCustomObject]@{ "Item" = "Fabric Interconnects"; "Value" = $fabricInterconnects.Count }
        [PSCustomObject]@{ "Item" = "Chassis"; "Value" = $chassis.Count }
        [PSCustomObject]@{ "Item" = "IO Modules"; "Value" = $iom.Count }
        [PSCustomObject]@{ "Item" = "Blade Servers"; "Value" = $servers.Count }
        [PSCustomObject]@{ "Item" = "Active Faults"; "Value" = $faults.Count }
        [PSCustomObject]@{ "Item" = "Critical / Major / Minor"; "Value" = "$criticalCount / $majorCount / $minorCount" }
        [PSCustomObject]@{ "Item" = "Health Score"; "Value" = "$healthScore / 100" }
    )

    if ($IncludeRawCsv) {
        $datasets = @{
            "FabricInterconnect" = $fabricInterconnects
            "Chassis" = $chassis
            "IOModule" = $iom
            "PSUInventory" = $psuInventory
            "Servers" = $servers
            "ServerPower" = $serverPower
            "Faults" = $faults
            "ServiceProfiles" = $serviceProfiles
            "Firmware" = $firmwareSummary
            "Licenses" = $licenseSummary
            "RawServerPorts" = $serverPorts
            "RawUplinkPorts" = $uplinkPorts
            "RawFcPorts" = $fcUplinkPorts
            "RawAppliancePorts" = $appliancePorts
            "RawLicenseFeatures" = $licenseFeatures
            "RawLicenseLines" = $licenseLines
            "RawFabricPorts" = $fabricPorts
        }
        foreach ($name in $datasets.Keys) {
            @($datasets[$name]) | Export-Csv (Join-Path $reportFolder "$name.csv") -NoTypeInformation -Encoding UTF8
        }
    }

    Write-Progress -Activity "UCS Health Check" -Status "Generating HTML report" -PercentComplete 92
    $css = @"
<style>
@page { size: A4 landscape; margin: 10mm; }
body { font-family: Arial, Helvetica, sans-serif; color: #222; margin: 18px; font-size: 11px; }
h1 { font-size: 24px; margin: 0 0 4px 0; }
.subtitle { color: #666; margin-bottom: 20px; }
h2 { font-size: 15px; margin-top: 24px; margin-bottom: 7px; padding-bottom: 4px; border-bottom: 1px solid #777; page-break-after: avoid; }
section { margin-bottom: 18px; }
table { width: 100%; border-collapse: collapse; margin-bottom: 14px; }
th { background: #e7e7e7; font-weight: bold; text-align: left; border: 1px solid #c7c7c7; padding: 5px; white-space: nowrap; }
td { border: 1px solid #d2d2d2; padding: 5px; vertical-align: top; word-break: break-word; }
tr:nth-child(even) td { background: #fafafa; }
.empty { color: #777; font-style: italic; }
.summary { width: 55%; }
.bad { background: #ffd6d6 !important; }
.footer { margin-top: 25px; color: #777; font-size: 9px; border-top: 1px solid #ccc; padding-top: 7px; }
@media print { section { page-break-inside: auto; } thead { display: table-header-group; } tr { page-break-inside: avoid; } }
</style>
"@

    $body = @"
<h1>Cisco UCS Health Check Report</h1>
<div class="subtitle">$domainName ($UcsIp) | UCSM $ucsmVersion</div>
$(ConvertTo-HtmlTable -Title "1. Executive Summary" -Data $summary -CssClass "summary")
$(ConvertTo-HtmlTable -Title "1.1.1 Fabric Interconnect" -Data $fabricInterconnects)
$(ConvertTo-HtmlTable -Title "1.1.2.1 Chassis" -Data $chassis)
$(ConvertTo-HtmlTable -Title "1.1.2.2 IO Module" -Data $iom)
$(ConvertTo-HtmlTable -Title "1.1.2.3 Power Supply Units" -Data $psuInventory)
$(ConvertTo-HtmlTable -Title "1.1.3 Server UCS" -Data $servers)
$(ConvertTo-HtmlTable -Title "1.1.3.1 Server Power Statistics" -Data $serverPower)
$(ConvertTo-HtmlTable -Title "1.1.4 Active Faults" -Data $faults)
$(ConvertTo-HtmlTable -Title "1.1.5 Service Profiles" -Data $serviceProfiles)
$(ConvertTo-HtmlTable -Title "1.1.6 Firmware Inventory" -Data $firmwareSummary)
$(ConvertTo-HtmlTable -Title "1.1.7 License Summary" -Data $licenseSummary)
<div class="footer">Generated with Cisco UCS PowerTool - Internal Report Generator v8. Port counts are derived from active/configured UCS port objects. Raw port and license objects are exported when -IncludeRawCsv is used.</div>
"@

    ConvertTo-Html -Title "Cisco UCS Health Check Report" -Head $css -Body $body |
        Set-Content -Path $htmlPath -Encoding UTF8

    Write-Progress -Activity "UCS Health Check" -Completed
    Write-Host ""
    Write-Host "Report berhasil dibuat:" -ForegroundColor Green
    Write-Host $htmlPath -ForegroundColor Cyan
    if ($IncludeRawCsv) { Write-Host "CSV tersimpan di: $reportFolder" -ForegroundColor Cyan }

    if ($OpenReport) { Start-Process $htmlPath }
}
finally {
    try { Disconnect-Ucs -Ucs $connection -ErrorAction SilentlyContinue | Out-Null } catch { }
}
