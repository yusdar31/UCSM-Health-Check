Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

.\Generate-UCSHealthCheck.ps1 `
    -UcsIp "192.0.2.10" `
    -PrimaryFabric A `
    -OutputDirectory "C:\UCS-Report" `
    -IncludeRawCsv `
    -OpenReport
