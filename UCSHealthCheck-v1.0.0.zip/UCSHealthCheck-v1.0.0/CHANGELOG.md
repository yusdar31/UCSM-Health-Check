# Changelog

All notable changes to this project are documented in this file.

## [1.0.0] - 2026-07-24

### Added

- Cisco UCS Manager inventory collection
- HTML health report
- Standard and raw CSV export
- Fabric Interconnect, chassis, IOM, blade, PSU, power, fault, firmware, Service Profile, port, and license reporting
- Health score calculation
- Automatic stale UCS PowerTool session cleanup
- English documentation and sanitized examples
