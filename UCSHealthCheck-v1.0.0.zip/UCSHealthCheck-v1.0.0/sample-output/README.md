# Sample Output

Do not publish unsanitized production reports.

Before adding sample files, remove or replace:

- real IP addresses and hostnames;
- usernames and organization names;
- serial numbers;
- Service Profile names;
- fault details that expose internal topology;
- any other confidential operational data.
