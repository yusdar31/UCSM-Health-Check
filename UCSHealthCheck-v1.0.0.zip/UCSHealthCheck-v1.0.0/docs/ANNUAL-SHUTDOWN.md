# Annual Shutdown Workflow

## Before Shutdown

1. Run the health check with raw CSV export.
2. Confirm there are no unresolved Critical or Major faults.
3. Verify Fabric Interconnect HA, chassis, IOM, PSU, blade, and thermal status.
4. Save an approved UCS Manager Full State Backup.
5. Save a System Configuration Backup.
6. Save a Tech Support bundle when required by the operating procedure.
7. Store the report and backup evidence in an approved repository.

```powershell
.\Generate-UCSHealthCheck.ps1 `
  -UcsIp "192.0.2.10" `
  -PrimaryFabric A `
  -OutputDirectory "D:\Annual-Shutdown\PRE-SHUTDOWN" `
  -IncludeRawCsv `
  -OpenReport
```

## After Startup

1. Wait until Fabric Interconnects, IOMs, chassis, and blades stabilize.
2. Run the health check again.
3. Compare pre-shutdown and post-startup device totals.
4. Compare Service Profile associations.
5. Review new, cleared, or changed faults.
6. Verify firmware, power, thermal, and operability.
7. Record any deviation and remediation action.

```powershell
.\Generate-UCSHealthCheck.ps1 `
  -UcsIp "192.0.2.10" `
  -PrimaryFabric A `
  -OutputDirectory "D:\Annual-Shutdown\POST-STARTUP" `
  -IncludeRawCsv `
  -OpenReport
```
