# Installation

## Prerequisites

- Windows PowerShell 5.1
- Cisco UCS PowerTool with the `Cisco.UCSManager` module
- Network access to the UCS Manager virtual IP or hostname on TCP 443
- A UCS account with sufficient read permissions

## Verification

```powershell
$PSVersionTable.PSVersion
Get-Module Cisco.UCSManager -ListAvailable
Test-NetConnection 192.0.2.10 -Port 443
```

Replace `192.0.2.10` with your UCS Manager virtual IP.

## Run

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\Generate-UCSHealthCheck.ps1 -UcsIp "192.0.2.10" -IncludeRawCsv -OpenReport
```
