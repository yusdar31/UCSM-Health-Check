# Troubleshooting

## Script execution is blocked

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

## Cisco.UCSManager is not available

```powershell
Get-Module Cisco.UCSManager -ListAvailable
```

Install or repair Cisco UCS PowerTool using your approved software process.

## Connection fails

```powershell
Test-Connection 192.0.2.10 -Count 2
Test-NetConnection 192.0.2.10 -Port 443
```

Check the virtual IP or hostname, credentials, account status, routing, firewall, and UCS Manager availability.

## Duplicate inventory

```powershell
Get-UcsPSSession
Get-UcsPSSession | ForEach-Object {
    Disconnect-Ucs -Ucs $_ -ErrorAction SilentlyContinue
}
```

The current script performs this cleanup automatically.

## Blank or N/A values

Object properties may differ between UCS Manager, hardware, firmware, and PowerTool versions. Enable `-IncludeRawCsv` and inspect the generated raw data.

## Port totals look incorrect

Review:

- `RawFabricPorts.csv`
- `RawServerPorts.csv`
- `RawUplinkPorts.csv`
- `RawFcPorts.csv`
- `RawAppliancePorts.csv`

## License data is incomplete

Review:

- `RawLicenseFeatures.csv`
- `RawLicenseLines.csv`

## HTML does not open automatically

The report remains in the timestamped output folder even when the default browser cannot be started.
