# Cisco UCS Health Check

PowerShell-based inventory and health reporting for Cisco UCS Manager using Cisco UCS PowerTool.

## Overview

Cisco UCS Health Check collects inventory, operational status, firmware, power statistics, active faults, service profiles, port information, and license data from Cisco UCS Manager. It generates an HTML report and optional CSV exports for operational review, audit evidence, and annual shutdown validation.

No credentials are stored in the script. The operator is prompted for a username and password at runtime.

## Features

- Executive summary and health score
- Fabric Interconnect inventory
- Chassis inventory and slot utilization
- I/O Module inventory
- Blade server inventory
- CIMC and firmware information
- Server power statistics
- Active fault summary
- Service Profile mapping
- License summary
- Port classification and utilization
- HTML report generation
- Standard and raw CSV export
- Automatic cleanup of stale UCS PowerTool sessions

## Requirements

| Component | Requirement |
|---|---|
| Operating system | Windows 10, Windows 11, or Windows Server |
| PowerShell | Windows PowerShell 5.1 recommended |
| Cisco module | `Cisco.UCSManager` |
| Network access | HTTPS access to the Cisco UCS Manager virtual IP or hostname |
| UCS account | Read access to inventory and health objects |

The script was validated with:

- Cisco UCS Manager 4.3(6f)
- Cisco UCS PowerTool 3.0.6.21
- Windows PowerShell 5.1

Other versions may expose different object properties. Review the raw CSV exports when a field is blank or unexpected.

## Repository Structure

```text
UCSHealthCheck/
├── Generate-UCSHealthCheck.ps1
├── README.md
├── CHANGELOG.md
├── LICENSE
├── .gitignore
├── docs/
│   ├── INSTALLATION.md
│   ├── TROUBLESHOOTING.md
│   └── ANNUAL-SHUTDOWN.md
├── examples/
│   └── Run-HealthCheck.ps1
└── sample-output/
    └── README.md
```

## Installation

### 1. Clone the repository

```powershell
git clone https://github.com/your-username/UCSHealthCheck.git
cd UCSHealthCheck
```

Alternatively, download and extract the release archive.

### 2. Verify PowerShell

```powershell
$PSVersionTable.PSVersion
```

### 3. Verify Cisco UCS PowerTool

```powershell
Get-Module Cisco.UCSManager -ListAvailable |
    Select-Object Name, Version, ModuleBase
```

If the module is not available, install Cisco UCS PowerTool according to your organization's approved software process.

### 4. Allow script execution for the current session

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

This does not permanently change the computer-wide execution policy.

## Usage

### Basic run

```powershell
.\Generate-UCSHealthCheck.ps1 -UcsIp "192.0.2.10"
```

`192.0.2.10` is a documentation-only example address. Replace it with your UCS Manager virtual IP or resolvable hostname.

### Complete run

```powershell
.\Generate-UCSHealthCheck.ps1 `
  -UcsIp "192.0.2.10" `
  -PrimaryFabric A `
  -OutputDirectory "C:\UCS-Report" `
  -IncludeRawCsv `
  -OpenReport
```

The script prompts for credentials:

```text
UCS Manager username:
UCS Manager password:
```

### Use a hostname

```powershell
.\Generate-UCSHealthCheck.ps1 `
  -UcsIp "ucs-manager.example.com" `
  -OutputDirectory "D:\Reports\Cisco-UCS" `
  -IncludeRawCsv
```

## Parameters

| Parameter | Required | Default | Description |
|---|---:|---|---|
| `-UcsIp` | Yes | None | UCS Manager virtual IP address or hostname |
| `-PrimaryFabric` | No | `A` | Expected primary Fabric Interconnect, either `A` or `B` |
| `-OutputDirectory` | No | `C:\UCS-Report` | Parent directory for generated report folders |
| `-IncludeRawCsv` | No | Disabled | Exports raw PowerTool data used for troubleshooting and validation |
| `-OpenReport` | No | Disabled | Opens the generated HTML report with the default browser |

## Generated Output

Each run creates a timestamped directory under the selected output path.

```text
C:\UCS-Report\YYYYMMDD-HHMMSS\
```

Typical files include:

```text
UCS-Health-Check-YYYYMMDD-HHMMSS.html
FabricInterconnect.csv
Chassis.csv
IOModule.csv
PSUInventory.csv
Servers.csv
ServerPower.csv
Faults.csv
ServiceProfiles.csv
Firmware.csv
Licenses.csv
```

When `-IncludeRawCsv` is enabled, the report may also include:

```text
RawFabricPorts.csv
RawServerPorts.csv
RawUplinkPorts.csv
RawFcPorts.csv
RawAppliancePorts.csv
RawLicenseFeatures.csv
RawLicenseLines.csv
```

## Report Sections

### Executive Summary

Displays the UCS domain, UCS Manager version, collection time, device counts, active fault counts, and calculated health score.

### Fabric Interconnects

Displays Fabric ID, cluster role, model, serial number, management IP, firmware, port usage, operability, and thermal condition.

### Chassis

Displays model, serial number, power condition, PSU status, thermal condition, and blade slot utilization.

### I/O Modules

Displays chassis association, fabric assignment, model, serial number, firmware, channel or slot, and operability.

### Blade Servers

Displays chassis, slot, model, serial number, Service Profile, CPU count, core count, memory, CIMC firmware, power state, thermal condition, and operational status.

### Server Power Statistics

Displays available consumed power, average and maximum power, current, voltage, and suspect-state metrics.

### Active Faults

Displays severity, fault code, affected object, description, creation time, and last transition time.

### Service Profiles

Displays Service Profile name, organization, blade association, association state, operability, and template type.

### Firmware and Licenses

Displays firmware objects and license information exposed by the installed UCS PowerTool and UCS Manager version.

## Validation After Each Run

Compare the generated report with Cisco UCS Manager and confirm:

1. Each Fabric Interconnect appears once.
2. Each chassis appears once.
3. Each blade serial number appears once.
4. Device totals match the UCS Manager inventory.
5. Service Profiles map to the correct blades.
6. Active faults match the UCS Manager fault view.
7. The expected primary Fabric Interconnect is reported correctly.
8. Output files exist and are not empty.

## Session Handling

The script disconnects stale UCS PowerTool sessions before creating a new connection. This prevents duplicate inventory caused by querying the same UCS domain through multiple active default sessions.

Check sessions manually:

```powershell
Get-UcsPSSession
```

Disconnect all sessions manually:

```powershell
Get-UcsPSSession | ForEach-Object {
    Disconnect-Ucs -Ucs $_ -ErrorAction SilentlyContinue
}
```

Avoid running multiple copies of the script from the same PowerShell session at the same time.

## Security Notes

- Do not hard-code UCS credentials in the script.
- Prefer a read-only reporting account when organizational policy permits.
- Treat generated reports as sensitive operational data.
- Reports may contain hostnames, IP addresses, serial numbers, Service Profile names, faults, and infrastructure topology.
- Do not commit generated reports or raw CSV exports to a public repository.
- Review all screenshots and sample output before publication.
- The script accepts self-signed UCS Manager certificates. Confirm that the target address is correct before entering credentials.

## Troubleshooting

See [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) for detailed guidance.

Common checks:

```powershell
Test-Connection 192.0.2.10 -Count 2
Test-NetConnection 192.0.2.10 -Port 443
Get-Module Cisco.UCSManager -ListAvailable
Get-UcsPSSession
```

## Annual Shutdown Workflow

See [docs/ANNUAL-SHUTDOWN.md](docs/ANNUAL-SHUTDOWN.md).

Recommended workflow:

1. Run a pre-shutdown report with raw CSV export.
2. Save UCS Manager backups and required support bundles.
3. Store the pre-shutdown report in an approved location.
4. After startup, wait until the UCS domain stabilizes.
5. Run a post-startup report.
6. Compare inventory, firmware, faults, Service Profiles, power, and operability.

## Syntax Validation

Validate the script without connecting to UCS Manager:

```powershell
$errors = $null
[System.Management.Automation.Language.Parser]::ParseFile(
    ".\Generate-UCSHealthCheck.ps1",
    [ref]$null,
    [ref]$errors
) | Out-Null

$errors
```

No output means no PowerShell parser errors were found.

## Versioning

The repository uses semantic versioning:

```text
MAJOR.MINOR.PATCH
```

Example:

```text
1.0.0
```

- **MAJOR**: incompatible behavior or structure changes
- **MINOR**: backward-compatible features
- **PATCH**: backward-compatible fixes

## Roadmap

- [x] HTML report
- [x] Standard CSV export
- [x] Raw CSV export
- [x] Fabric, chassis, IOM, and blade inventory
- [x] Power statistics
- [x] Fault summary
- [x] Health score
- [x] Duplicate-session prevention
- [ ] Excel workbook export
- [ ] Native PDF export
- [ ] Email delivery
- [ ] Report comparison mode
- [ ] Intersight integration
- [ ] Automated PowerShell linting in GitHub Actions

## Contributing

Issues and pull requests are welcome. Before submitting a change:

1. Remove real IP addresses, hostnames, usernames, serial numbers, and organization names.
2. Validate PowerShell syntax.
3. Test against a non-production or read-only environment where possible.
4. Explain the PowerTool and UCS Manager versions used for testing.
5. Include sanitized raw output when property mapping is relevant.

## Disclaimer

This project is an independent operational reporting utility and is not an official Cisco product. Cisco, Cisco UCS, and related names are trademarks of Cisco Systems, Inc.

Always validate generated results against Cisco UCS Manager before using them for production decisions, compliance evidence, upgrades, shutdown activities, or incident response.

## License

Released under the MIT License. See [LICENSE](LICENSE).
